package com.nomyagenda.app.data.preferences

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat

class SettingsRepository(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var themeMode: String
        get() = prefs.getString(KEY_THEME, THEME_SYSTEM) ?: THEME_SYSTEM
        set(value) = prefs.edit().putString(KEY_THEME, value).apply()

    var decorativeTheme: String
        get() = prefs.getString(KEY_DECORATIVE_THEME, DECORATIVE_THEME_DEFAULT) ?: DECORATIVE_THEME_DEFAULT
        set(value) = prefs.edit().putString(KEY_DECORATIVE_THEME, value).apply()

    var language: String
        get() = prefs.getString(KEY_LANGUAGE, LANGUAGE_SYSTEM) ?: LANGUAGE_SYSTEM
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    var notificationsEnabled: Boolean
        get() = prefs.getBoolean(KEY_NOTIFICATIONS, true)
        set(value) = prefs.edit().putBoolean(KEY_NOTIFICATIONS, value).apply()

    var appBackground: String
        get() = prefs.getString(KEY_APP_BACKGROUND, APP_BACKGROUND_NONE) ?: APP_BACKGROUND_NONE
        set(value) = prefs.edit().putString(KEY_APP_BACKGROUND, value).apply()

    var lockType: String
        get() = prefs.getString(KEY_LOCK_TYPE, LOCK_TYPE_NONE) ?: LOCK_TYPE_NONE
        set(value) = prefs.edit().putString(KEY_LOCK_TYPE, value).apply()

    var lockPatternHash: String
        get() = prefs.getString(KEY_LOCK_PATTERN_HASH, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LOCK_PATTERN_HASH, value).apply()

    var lockBackgroundTimeoutMs: Long
        get() = prefs.getLong(KEY_LOCK_BACKGROUND_TIMEOUT_MS, LOCK_TIMEOUT_DEFAULT_MS)
        set(value) = prefs.edit().putLong(KEY_LOCK_BACKGROUND_TIMEOUT_MS, value).apply()

    fun applyTheme() {
        // Thematic (non-default) themes and illustrated backgrounds use fixed light colours,
        // so force light mode. When neither is active, honour the stored day/night preference.
        val mode = when {
            decorativeTheme != DECORATIVE_THEME_DEFAULT -> AppCompatDelegate.MODE_NIGHT_NO
            appBackground != APP_BACKGROUND_NONE -> AppCompatDelegate.MODE_NIGHT_NO
            else -> when (themeMode) {
                THEME_LIGHT -> AppCompatDelegate.MODE_NIGHT_NO
                THEME_DARK -> AppCompatDelegate.MODE_NIGHT_YES
                else -> AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM
            }
        }
        AppCompatDelegate.setDefaultNightMode(mode)
    }

    fun applyLanguage() {
        val localeList = when (language) {
            LANGUAGE_ES -> LocaleListCompat.forLanguageTags("es")
            LANGUAGE_EN -> LocaleListCompat.forLanguageTags("en")
            else -> LocaleListCompat.getEmptyLocaleList()
        }
        AppCompatDelegate.setApplicationLocales(localeList)
    }

    companion object {
        const val PREFS_NAME = "nomy_settings"
        const val KEY_THEME = "theme_mode"
        const val KEY_DECORATIVE_THEME = "decorative_theme"
        const val KEY_LANGUAGE = "language"
        const val KEY_NOTIFICATIONS = "notifications_enabled"
        const val KEY_APP_BACKGROUND = "app_background"
        const val KEY_LOCK_TYPE = "lock_type"
        const val KEY_LOCK_PATTERN_HASH = "lock_pattern_hash"
        const val KEY_LOCK_BACKGROUND_TIMEOUT_MS = "lock_background_timeout_ms"

        const val THEME_LIGHT = "LIGHT"
        const val THEME_DARK = "DARK"
        const val THEME_SYSTEM = "SYSTEM"

        const val DECORATIVE_THEME_DEFAULT = "DEFAULT"
        const val DECORATIVE_THEME_OCEAN = "OCEAN"
        const val DECORATIVE_THEME_FOREST = "FOREST"
        const val DECORATIVE_THEME_SUNSET = "SUNSET"

        const val APP_BACKGROUND_NONE = "NONE"
        const val APP_BACKGROUND_FLORAL = "FLORAL"
        const val APP_BACKGROUND_STARS = "STARS"
        const val APP_BACKGROUND_GEOMETRIC = "GEOMETRIC"
        const val APP_BACKGROUND_DOTS = "DOTS"
        const val APP_BACKGROUND_LEAVES = "LEAVES"
        const val APP_BACKGROUND_BUTTERFLY = "BUTTERFLY"
        const val APP_BACKGROUND_MANDALA = "MANDALA"
        const val APP_BACKGROUND_MOUNTAINS = "MOUNTAINS"
        const val APP_BACKGROUND_WAVES = "WAVES"

        const val LANGUAGE_ES = "es"
        const val LANGUAGE_EN = "en"
        const val LANGUAGE_SYSTEM = "system"

        const val LOCK_TYPE_NONE = "NONE"
        const val LOCK_TYPE_PATTERN = "PATTERN"
        const val LOCK_TYPE_BIOMETRIC = "BIOMETRIC"
        const val LOCK_TIMEOUT_DEFAULT_MS = 30_000L

        const val ADVANCE_NOTICE_NONE = 0
        const val ADVANCE_NOTICE_1H = 60
        const val ADVANCE_NOTICE_1D = 1440
        const val ADVANCE_NOTICE_1W = 10080
    }
}
